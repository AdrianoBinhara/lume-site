---
name: consolidar-indice
description: "Revisa à noite o que o Lume aprendeu sozinho no dia: junta coisas aprendidas repetidas, corrige ou apaga as erradas, marca tarefas feitas, atualiza as fichas das pessoas e projetos que ganharam coisas novas e escreve de 3 a 5 insights com evidência. Use na rotina da noite, depois do fechamento, e quando a pessoa pedir pra arrumar o que o Lume aprendeu."
allowed-tools: Read(~/Lume/**), Edit(memoria/**), Skill, mcp__lume__indice_status, mcp__lume__indice_fatos, mcp__lume__indice_fatos_editar, mcp__lume__indice_buscar, mcp__lume__indice_pessoa, mcp__lume__indice_linha_do_tempo, mcp__lume__indice_insights, mcp__lume__indice_insight_salvar, mcp__lume__memoria_buscar, mcp__lume__memoria_ler, mcp__lume__memoria_salvar
---

Faça você mesmo, sem delegar. Ninguém está digitando: nada de perguntas. Escreva só no índice (pelas ferramentas `indice_*`) e em `memoria/`.

O modelo do Mac aprende o dia inteiro com o que as fontes trazem. É rápido e de graça, mas às vezes diz a mesma coisa com outras palavras, troca quem é quem ou guarda o que não importa. À noite você revisa, com calma e com limite.

## Limites
- No máximo 300 coisas aprendidas por noite: as das últimas 24 horas antes de "Agora:", das mais importantes pras menos. O que passar disso fica pra amanhã.
- Nunca mexa no que está fixado: fixar e soltar é decisão da pessoa.
- Na dúvida entre corrigir e deixar, deixe. Apagar só o que está errado ou não vale nada.
- Nada de texto literal de mensagem ou e-mail, nunca segredo, saúde, finanças ou vida íntima de terceiros, nem no índice nem na memória.

## Passos
1. `indice_status` pra ver o tamanho do dia. Depois `indice_fatos` com `desde` 24 horas antes de "Agora:" e `limite` 100. Se vier cheio, repita por `tipo` (`decisao`, `tarefa`, `evento`, `fato`, `relacao`, `preferencia`, `ideia`, `aprendizado`) até cobrir o dia ou chegar a 300. Fique com as de `criado` nas últimas 24 horas.
2. Repetidos: duas ou mais com o mesmo assunto, a mesma pessoa e o mesmo momento ("Ana manda o contrato sexta" e "Contrato da Ana chega na sexta") viram uma só. `indice_fatos_editar` com `acao: fundir`, os `ids` e o `conteudo` novo: a frase mais clara e completa, com quem, o quê e quando. Pra achar a mesma coisa aprendida em dias anteriores, `indice_buscar` com duas ou três palavras do assunto e a pessoa.
3. Errados: pessoa trocada, data impossível, conclusão que a evidência não sustenta. `indice_linha_do_tempo` em volta da data, com a pessoa, mostra o que foi dito de fato. Conserte com `acao: corrigir` e o `conteudo` certo, ou `apagar` quando não se salva. Coisa sem valor também sai com `apagar`: logística que já passou ("chego em 5 min"), "mandou um áudio", saudação, propaganda.
4. Tarefas: combinado que os registros mostram resolvido vira `feito`.
5. Fichas: pras pessoas e projetos que ganharam coisas novas hoje, siga a skill `construir-mente` (ficha curta, item só pro que merece a memória). `indice_pessoa` dá o resumo atualizado. Procure antes de criar e edite o que existe; a rotina do fechamento pode já ter mexido nelas hoje.
6. Insights: `indice_insights` com `limite` 30 pra ver o que já foi dito. Escreva de 3 a 5 novos com `indice_insight_salvar`, só o que muda alguma coisa pra pessoa e ainda não apareceu antes:
   - relação: "Faz 3 semanas que você não responde o Marcos", "A Ana voltou a falar do contrato depois de um mês";
   - número com tendência: "Assinantes do Meu App +12% na semana", "Receita de ontem foi a metade da média";
   - compromisso em risco: "Você prometeu a proposta pra sexta e ela não saiu";
   - ligação que ela não vê: "Três pessoas pediram a mesma função esta semana".
   Cada insight leva `tipo` (`relacao`, `numero`, `compromisso` ou `padrao`), `titulo` de até 70 caracteres, `corpo` de até 3 frases curtas e `evidencia` com os ids reais que sustentam: `{tipo: fato, id}` das coisas aprendidas ou `{tipo: registro, id}` das mensagens, e-mails e eventos (os ids vêm de `indice_fatos`, `indice_buscar` e `indice_linha_do_tempo`). Sem evidência, não é insight. Óbvio também não é ("você mandou muitas mensagens hoje"). Se nada novo valer a pena, não escreva nenhum.

## Resposta
Na rotina, que é silenciosa: responda exatamente `NADA`. Os insights aparecem no briefing da manhã. Se não conseguiu usar o índice (erro de ferramenta), responda uma linha dizendo isso. Quando a pessoa pedir na conversa, uma linha: "Índice: 12 juntados, 3 corrigidos, 5 apagados, 4 insights".
