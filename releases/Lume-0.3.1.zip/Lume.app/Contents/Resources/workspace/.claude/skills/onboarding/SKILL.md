---
name: onboarding
description: "Primeiro uso: o Lume descobre sozinho quem é a pessoa (cartão Eu Mesmo, sistema, e-mail, agenda, reuniões, Otto, Linear, pegada digital, web) antes de perguntar qualquer coisa, grava um rascunho de memoria/eu.md e só confirma ou pergunta o que faltou. Use quando eu.md ainda tiver a linha lume:template, ou quando a pessoa pedir pra recomeçar ou refazer a apresentação."
allowed-tools: Read(~/Lume/**), Edit(memoria/**), mcp__lume__eu_contexto, mcp__lume__contatos_buscar, mcp__lume__gmail_buscar, mcp__lume__gmail_ler, mcp__lume__agenda_listar, mcp__lume__pegada_resumo, mcp__lume__pegada_buscar, mcp__lume__youtube_canal, mcp__lume__whatsapp_conversas, mcp__lume__imessage_conversas, mcp__lume__memoria_buscar, mcp__lume__memoria_ler, mcp__lume__memoria_salvar, mcp__otto__start_here, mcp__otto__whoami, mcp__otto__get_voice_profile, mcp__granola__query_granola_meetings, mcp__granola__list_meetings, mcp__granola__get_meetings, mcp__granola__get_meeting_transcript, mcp__granola__list_meeting_folders, mcp__granola__get_account_info, mcp__linear__list_teams, mcp__linear__get_team, mcp__linear__list_users, mcp__linear__get_user, mcp__linear__list_issues, mcp__linear__get_issue, mcp__linear__list_issue_statuses, mcp__linear__list_issue_labels, mcp__linear__list_comments, mcp__linear__list_cycles, mcp__linear__list_projects, mcp__linear__get_project, mcp__linear__list_documents, mcp__linear__get_document, mcp__linear__search_documentation
---

Regra número um: nunca pergunte o que dá pra descobrir. A pessoa acabou de instalar o Lume. Perguntar a cidade dela quando o Mac sabe a cidade é o jeito mais rápido de perder a confiança.

## 1. Descobrir, antes de qualquer mensagem
Chame o que estiver ligado. O que devolver "Não configurado" ou erro, pule em silêncio, sem comentar.
- `eu_contexto`: nome, e-mails, telefones, cidade, empresa, cargo, redes, idioma do sistema, região, fuso. A fonte principal.
- `contatos_buscar` com o nome da pessoa: confirma o cartão.
- `gmail_buscar` com `from:me newer_than:30d`, limite 10, e `gmail_ler` em 2 ou 3: assinatura (cargo, empresa, telefone), língua em que escreve, com quem mais troca e-mail.
- `agenda_listar` dos últimos 14 dias e dos próximos 14: ritmo de trabalho, reuniões recorrentes, nomes que se repetem.
- Granola: reuniões recentes (títulos, participantes, temas).
- Otto: `whoami` e `get_voice_profile`: contas, voz, temas.
- Linear: times e projetos.
- `pegada_resumo`: perfil, contagens e destaques do LinkedIn, X, Instagram, TikTok e Facebook/Threads já importados. `youtube_canal` se houver.
- `memoria_ler` com `pastas`: as fichas dos projetos das pastas sincronizadas, se a pessoa ligou alguma em Fontes. Clientes e setores recorrentes dizem muito sobre o trabalho dela.
- `whatsapp_conversas` e `imessage_conversas` com limite 20: só nomes e frequência, pra saber quem mais importa. Não leia as mensagens.
- WebSearch com o nome e os handles: site pessoal, LinkedIn público, o que a pessoa publica. Pede aprovação dela (ela está na conversa); se recusar, siga sem. Só nome e handles na busca, nunca e-mail ou telefone.

Como inferir: idioma é a língua em que a pessoa te escreveu, e `idioma_sistema` desempata. Cidade vem do cartão, do fuso e da assinatura de e-mail. Trabalho vem do cargo e da empresa do cartão, da assinatura e do LinkedIn. Pessoas são quem se repete em agenda, e-mail e mensagens. Projetos vêm do Linear, do Granola, dos repositórios citados e dos posts.

## 2. Rascunhar a memória
Escreva `memoria/eu.md` com o que descobriu (Edit, trocando os parênteses de cada seção) e, nessa mesma edição, apague a linha `<!-- lume:template -->`: enquanto ela existe, o app considera o arquivo vazio e a Mente não mostra nada. O que ainda não foi confirmado fica marcado com "(a confirmar)" no texto; é isso que diz que o onboarding continua. Preencha `fontes` no frontmatter com o que usou (`eu_contexto`, `gmail`, `agenda`...). Crie `pessoas/<slug>.md` pras 3 a 5 pessoas mais presentes e `projetos/<slug>.md` pros projetos claros, com frontmatter e links `[[slug]]` nos dois sentidos. Se a pegada digital veio, aplique a skill `pegada-digital` (carreira e presença digital em `fatos/`).

## 3. Uma mensagem só
Apresente-se em uma linha e mostre o que inferiu em até 6 linhas, em tom de quem reconhece a pessoa, não de quem leu uma ficha: "Vi que você é a Ana, mora em Curitiba, é CTO na Acme e toca o app Tal com o Marcos. Falo com você em português. Acertei?". Feche com no máximo 2 perguntas sobre o que ficou realmente em aberto, nesta ordem: como quer ser chamada (só se o nome tem variações), no que está gastando mais energia agora, como quer ajuda (tom, o que avisar sem pedir, o que nunca fazer sem perguntar).

## 4. Fechar
A cada resposta, grave na hora e tire os "(a confirmar)" do que foi confirmado. Na primeira vez que escrever em `preferencias.md`, apague a linha `<!-- lume:template -->` dele também. Quando o essencial estiver confirmado (quem é, trabalho, pessoas, como quer ajuda), ponha a data de hoje em `atualizado` dos dois arquivos e diga em 2 linhas que ela pode corrigir qualquer coisa só falando. Termine com uma pergunta útil: "Quer que eu olhe o que tem hoje?"
Nas conversas seguintes, enquanto houver "(a confirmar)" em `eu.md`, confirme um ou dois por conversa, sem transformar isso em entrevista. Se as fontes estão ligadas e a memória ainda está rala, rode a skill `construir-mente` com `todas`.

Se a pessoa disser "depois", pare, anote em `aprendizados.md` "AAAA-MM-DD: onboarding pausado" e retome em outro dia, sem insistir. Se perguntar outra coisa no meio, responda e volte.

## O que não fazer
- Perguntar cidade, idioma, nome, empresa ou cargo quando qualquer fonte já disse.
- Mandar lista de perguntas. Duas por vez, no máximo.
- Perguntar sobre integrações: você vê o que está ligado pelas ferramentas que respondem. Se algo relevante não estiver ligado (e-mail, agenda, redes), diga em uma linha onde liga: Fontes, no app; redes sociais em Fontes > Redes sociais > Pedir meus dados.
- Comentar dados de saúde ou mensagens privadas que viu de passagem.
