---
name: fichas-pastas
description: "Escreve a ficha de um projeto a partir de uma pasta sincronizada (OneDrive, Google Drive, Dropbox, iCloud Drive): uma página em memoria/pastas/<slug>.md com cliente, setor, o que foi feito, resultados e aprendizados, pessoas envolvidas e os links pros arquivos originais. O app monta o dossiê em anexos/pastas/<slug>.md e chama esta skill à noite, projeto por projeto. Use quando o app pedir ou quando a pessoa pedir a ficha de uma pasta."
argument-hint: "<slug>"
allowed-tools: Read(~/Lume/**), mcp__lume__memoria_ler, mcp__lume__memoria_buscar, mcp__lume__memoria_salvar
---

Argumento recebido: $ARGUMENTS (o slug do projeto).

Ninguém está esperando: nada de perguntas. O que não dá pra saber fica "(não identificado)".

## O que fazer
1. Leia `anexos/pastas/$ARGUMENTS.md` com Read. É o dossiê: o nome e o caminho do projeto, o frontmatter pronto, a lista de arquivos com os links `file://` e o texto já extraído de cada arquivo (já sem senhas, cartões e códigos). Arquivos que só existem na nuvem não foram lidos e não estão lá: não invente nada sobre eles.
2. Se já existe `memoria/pastas/$ARGUMENTS.md` (`memoria_ler`), leia antes: o que continua verdadeiro fica, o que mudou é reescrito. É uma página só; não acumule histórico.
3. Escreva a ficha inteira com `memoria_salvar` em `pastas/$ARGUMENTS.md`, modo `substituir`, neste formato:

```
<frontmatter copiado exatamente do dossiê>
# <nome do projeto, como no dossiê>

## Cliente
<quem é o cliente ou pra quem o trabalho foi feito, em uma linha; "(não identificado)" se não aparece>

## Setor
<setor ou mercado em uma ou duas palavras: fintech, varejo, saúde, educação...>

## O que foi feito
<de 3 a 6 linhas: o tipo de trabalho (diagnóstico, proposta, pesquisa, plano, treinamento, desenvolvimento), o período, as entregas; com datas quando os arquivos dizem>

## Resultados e aprendizados
<de 2 a 5 linhas: números, decisões, o que funcionou, o que deu errado, o que vale reaproveitar. Só o que está nos arquivos>

## Pessoas envolvidas
<só se ficar evidente nos arquivos (autores, assinaturas, equipe citada): nome e papel, uma por linha. Se não ficar, apague esta seção>

## Arquivos
<os links prontos do dossiê, do mais novo pro mais antigo, até 40; se houver mais, uma linha "e mais N arquivos na pasta">
```

## Regras
- Português do Brasil, frases curtas, suas. Nada de travessão. Uma página: até 60 linhas.
- Nunca copie parágrafos inteiros dos arquivos; resuma. Nunca escreva senha, token, chave, cartão, documento ou dado de saúde de alguém, mesmo que apareça.
- Não invente cliente, setor ou resultado pra preencher seção: use "(não identificado)".
- Os links são os do dossiê, sem alterar o caminho. Eles são a prova: quem lê a ficha abre o arquivo original por eles.
- Não crie nem edite nada fora de `memoria/pastas/`. Fichas de pessoas e projetos da Mente são de outra skill.

## Resposta
Uma linha só: "Ficha: <nome do projeto> (<n> arquivos)". Se o dossiê não existir ou estiver vazio: "Ficha: sem dossiê pra <slug>".
