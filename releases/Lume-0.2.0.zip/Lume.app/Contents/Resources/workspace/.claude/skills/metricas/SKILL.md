---
name: metricas
description: "Como ler as métricas dos apps e do negócio pelo Lume: metricas_apps mais os conectores ligados (Stripe, RevenueCat, Superwall, Supabase, PostHog, Mixpanel, Amplitude), períodos, comparação correta, o que é anomalia e como apresentar por app em uma linha. Use quando a pessoa perguntar de receita, downloads, assinaturas, conversão ou retenção, e na revisão semanal."
allowed-tools: Read, Grep, mcp__lume__metricas_apps, mcp__lume__memoria_buscar, mcp__lume__memoria_ler
---

## Fontes
- `metricas_apps` {periodo}: `ontem`, `7d`, `30d`, `mes`, `mes_passado`. Consolida App Store Connect e as fontes de fallback por app, e devolve `fontes_indisponiveis`. Comece sempre por aqui.
- Conectores: cada um ligado nos Ajustes aparece como servidor MCP com o id dele, e as ferramentas como `mcp__<id>__*`. Os nomes vêm de cada serviço; confira a lista da sessão. Leitura é liberada sozinha pelo app; qualquer escrita vai pra aprovação, e você não escreve em ferramenta de métrica.
  - `stripe`: receita, assinaturas, reembolsos, MRR, clientes.
  - `revenuecat`: assinaturas de app, trials, renovações, churn, MRR por app e por loja.
  - `superwall`: paywalls, impressões, conversão por paywall e por campanha.
  - `supabase`: tabelas e views da pessoa (usuários, eventos, o que ela guardar lá). Só consultas de leitura.
  - `posthog`, `mixpanel`, `amplitude`: produto: eventos, funis, retenção, ativos por dia, semana e mês.
- Use o que estiver ligado e ignore o resto sem comentar. Um conector que não responde entra na linha de fontes indisponíveis.
- Não some fontes que medem a mesma coisa: App Store Connect e RevenueCat se sobrepõem (proceeds e receita de assinatura), Stripe e RevenueCat também quando a cobrança é pelo Stripe. Escolha uma por pergunta e diga qual.
- Quais apps existem e onde cada um vive está em `memoria/projetos/`.

## Comparar certo
- Ontem contra a média diária de 7d (7d dividido por 7). Não contra o dia anterior isolado: dia da semana muda tudo.
- 7d contra a média de 30d (30d dividido por 30, vezes 7).
- Mês contra mês passado proporcional ao dia. Se hoje é dia 10, o mês atual tem 10 dias: diga que é parcial.
- Nos conectores, use o filtro de datas do próprio serviço com o mesmo tamanho de janela nos dois períodos, em São Paulo.
- Fontes medem coisas diferentes (receita bruta, líquida, proceeds, MRR). Compare cada uma com ela mesma.

## O que é anomalia
- Variação acima de 25% com base relevante (dezenas de eventos ou centenas de reais, no mínimo).
- Receita zerada onde havia receita.
- Fonte ou conector que parou de responder.
- Pico de reembolsos ou cancelamentos; queda de conversão de paywall; retenção caindo numa coorte nova.
Antes de chamar de problema, olhe `memoria/projetos/`: lançamento, campanha, mudança de preço, feriado.

## Como mostrar
- Uma linha por app: "App A: R$ 1.240 ontem (+8% vs média 7d), 310 downloads, 12 assinaturas novas".
- Depois só o que merece atenção, com a hipótese mais provável e o que checar.
- Fontes indisponíveis em uma linha no fim. Não repita o aviso em cada app.
- Moeda no formato da fonte (R$ ou US$), sem inventar conversão.
