---
name: otto
description: "Como usar o Otto pelo Lume pra posts no X, LinkedIn e Threads. O Otto recebe um briefing e escreve na voz da pessoa. Como montar o briefing, criar e editar rascunhos, ler o retorno, e o que só acontece com aprovação (publicar, agendar, apagar). Use sempre que o assunto for post ou conteúdo pra redes."
---

## Como o Otto funciona
- `create_post` recebe em `idea` um briefing (tema, ângulo, fatos, público), nunca um post pronto. Texto escrito por você contamina a voz da pessoa; esse é o erro mais comum.
- O texto que volta é a versão final do Otto. Mostre como veio. O `url` do retorno abre o rascunho no Otto, com login; não é link público.
- `network`: `x` (padrão), `linkedin`, `threads` (post único de até 500 caracteres). LinkedIn não aceita thread. Página de empresa no LinkedIn: `linkedinOrganizationId`; sem ele vai pro perfil pessoal.
- Artigo no X: `format: "article"` com `title` e `idea`. Depende da conta ter X Premium.
- Imagem: `imageUrl` (HTTPS do arquivo original) ou `imageBase64` com os bytes do arquivo. Só confirme a imagem se o retorno trouxer `imageAttached: true`. Vídeo: `videoUrl` (MP4, até 100 MiB). Nunca redimensione nem recrie a imagem.
- `edit_post` recebe uma instrução ("mais curto", "troca o gancho", "tira o emoji"), não texto substituto. Só rascunho ou aprovado aceita edição. Pedir agendamento por ele devolve `EDIT_IS_SCHEDULING`; agendar é `schedule_posts`.
- `verification` no retorno de criar ou editar: achados sobre o texto soar artificial. É aviso, não bloqueio. Mostre os achados e ofereça corrigir com a `rewriteInstruction` de cada um.
- Guarda anti-repetição: se recusar, mude gancho, tese ou exemplo. Não reenvie o mesmo briefing.

## Sem aprovação (leitura e rascunho)
`start_here` (sempre o primeiro da sessão: conta, guia e ferramentas liberadas), `whoami`, `get_voice_profile`, `list_memories`, `list_drafts`, `list_scheduled_posts`, `show_schedule`, `suggest_schedule_times`, `see_metrics`, `create_post`, `edit_post`.

## Com aprovação
`publish_post`, `schedule_posts`, `reschedule_post`, `cancel_schedule`, `delete_post`, `attach_image`, `save_memory`, `update_voice_profile` e o resto. Só chame quando a pessoa pediu aquilo. Agendar: `at` em horário local de São Paulo; use `suggest_schedule_times` ou `show_schedule` pra escolher. Só diga que foi ao ar quando o retorno mostrar publicado.

## Briefing que funciona
- Tema: sobre o que é.
- Ângulo: a opinião, a tese ou o gancho. Sem ângulo o post sai morno.
- Fatos: 2 a 4, com fonte (link, número, data).
- Público: pra quem é.
- Objetivo: conversa, cliques no link, posicionamento.
- Rede e formato: x, linkedin ou threads; post único ou thread.
- Restrições: idioma, o que não dizer, nomes que não podem aparecer.
- Link ou mídia, se houver.
Se faltar o ângulo, pergunte uma coisa só antes de criar. Puxe fatos de `memoria/`, de Notas, de reuniões ou da página que a pessoa mandou (WebFetch).
