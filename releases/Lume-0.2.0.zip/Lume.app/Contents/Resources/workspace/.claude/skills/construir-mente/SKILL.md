---
name: construir-mente
description: "Povoa a memória (a Mente) sozinho a partir do índice do Lume, onde já está tudo o que as fontes conectadas trouxeram. Pessoas e projetos viram fichas curtas; o que vale lembrar sobre eles (combinados, planos, números, decisões) vira itens pequenos pendurados neles. Use quando a pessoa conectar uma fonte, pedir pra preencher a Mente, perguntar por que a Mente está vazia ou só tem pessoas, ou na rotina da noite com o argumento todas hoje."
argument-hint: "[fonte] [janela]"
allowed-tools: Read, Grep, Glob, Edit(memoria/**), Skill, WebSearch, WebFetch, mcp__lume__indice_status, mcp__lume__indice_fatos, mcp__lume__indice_pessoa, mcp__lume__indice_buscar, mcp__lume__indice_linha_do_tempo, mcp__lume__indice_fatos_editar, mcp__lume__eu_contexto, mcp__lume__contatos_buscar, mcp__lume__imessage_conversas, mcp__lume__imessage_ler, mcp__lume__imessage_buscar, mcp__lume__whatsapp_conversas, mcp__lume__whatsapp_ler, mcp__lume__whatsapp_buscar, mcp__lume__gmail_buscar, mcp__lume__gmail_ler, mcp__lume__agenda_listar, mcp__lume__notas_listar, mcp__lume__notas_buscar, mcp__lume__notas_ler, mcp__lume__metricas_apps, mcp__lume__pegada_resumo, mcp__lume__pegada_buscar, mcp__lume__youtube_canal, mcp__lume__memoria_buscar, mcp__lume__memoria_ler, mcp__lume__memoria_salvar, mcp__granola__*, mcp__linear__list_*, mcp__linear__get_*, mcp__linear__search_*, mcp__otto__start_here, mcp__otto__whoami, mcp__otto__get_voice_profile, mcp__otto__list_memories, mcp__otto__list_drafts, mcp__otto__list_scheduled_posts, mcp__otto__list_instagram_posts, mcp__otto__see_metrics, mcp__notion__search*, mcp__notion__fetch*, mcp__notion__get_*, mcp__notion__list_*, mcp__notion__notion-search, mcp__notion__notion-fetch, mcp__stripe__list_*, mcp__stripe__get_*, mcp__stripe__retrieve_*, mcp__stripe__search_*, mcp__stripe__fetch_*, mcp__revenuecat__list_*, mcp__revenuecat__get_*, mcp__superwall__list_*, mcp__superwall__get_*, mcp__supabase__list_*, mcp__supabase__get_*
---

Argumentos recebidos: $ARGUMENTS

O primeiro argumento é a fonte: `whatsapp`, `imessage`, `notas`, `contatos`, `gmail`, `agenda`, o id de qualquer conector (`granola`, `linear`, `otto`, `notion`, `stripe`, `revenuecat`, `superwall`, `supabase`, `posthog`...), `pegada` ou uma plataforma (`linkedin`, `x`, `instagram`, `threads`, `tiktok`, `facebook`), ou `todas`. Sem argumento, vale `todas`. O segundo, opcional, é a janela: `hoje` (só o que mudou nas últimas 24 h) ou um período como `30d` ou `90d`.

Ninguém está esperando conversa durante a construção: nada de perguntas. Dúvida vira "(a confirmar)" no texto.

## Como a Mente é feita
A Mente é o que você aprendeu, não uma lista de contatos. Dois tipos de nota:
- **Fichas** (as âncoras): pessoas em `pessoas/` e projetos em `projetos/`. Empresa, app ou negócio da pessoa é projeto. A ficha diz quem é ou o que é, em uma ou duas linhas, com os links. Nada de histórico, status, pendência ou decisão dentro dela.
- **Itens**: cada coisa aprendida numa nota própria. Em `fatos/`: o que está acontecendo, combinado, plano com data, número, evento, problema em aberto. Em `decisoes/`: o que foi decidido, com data e por quem. O título é o próprio aprendizado, numa frase de até 70 caracteres. O primeiro link do texto é a âncora, a pessoa ou o projeto de que o item fala: no globo, o item orbita essa ficha.

A maior parte da Mente são itens: de 2 a 6 por ficha. Pessoa sem nada concreto pra contar não ganha ficha; projeto parado também não.

Item (`fatos/marcos-topou-preco-anual.md`):
```
---
tipo: fato
importancia: 3
atualizado: 2026-10-26
fontes: [whatsapp]
---
# Marcos topou o preço anual de R$ 99
[[marcos]] no [[meu-app]], em 2026-10-24. Quer lançar junto com a versão 2.
```

Ficha (`pessoas/marcos.md`):
```
---
tipo: pessoa
importancia: 4
atualizado: 2026-10-26
fontes: [whatsapp, agenda]
---
# Marcos
Sócio no [[meu-app]], cuida de vendas. Fala pelo WhatsApp quase todo dia.
```

Bons itens: "Combinou de mandar o contrato pra Ana até sexta", "Meu App tem 120 assinantes ativos (26/10)", "Semanal do Meu App às terças, 10h", "Ana sai de férias de 3 a 17/11", "Decidiu não ter plano mensal no Meu App". Itens ruins: "Fala pelo WhatsApp" (isso é ficha), "Trocaram 40 mensagens" (contagem não é aprendizado), "Conversam sobre trabalho" (vago).

## De onde vem: o índice
O app já leu as fontes ligadas e guardou tudo num índice neste Mac: os registros (mensagens, e-mails, eventos, notas, reuniões, issues, posts, métricas), as pessoas juntadas entre canais e as coisas aprendidas, que o modelo do Mac tira sozinho de cada conversa. Construa a partir dele, não lendo fonte por fonte.

1. `indice_status`: o que está indexado por fonte e quantas coisas aprendidas existem. Fonte com zero registros ainda não chegou ao índice: veja "Fonte que o índice ainda não tem".
2. `indice_fatos` com `desde` no começo da janela e `limite` 100. Se vier cheio, repita por `tipo` (`decisao`, `tarefa`, `evento`, `fato`, `relacao`, `preferencia`, `ideia`, `aprendizado`) até cobrir a janela, no máximo 400 por construção. Com uma fonte no argumento, fique com as que vieram dela (no índice, as plataformas da pegada aparecem como `pegada.<plataforma>`, como `pegada.linkedin`). Cada coisa aprendida traz `pessoas`, `projeto`, `importancia` (de 0 a 1), `vistos` (quantas vezes apareceu) e a data.
3. Agrupe por pessoa e por projeto. Ganha ficha quem tem pelo menos duas coisas aprendidas na janela, ou uma de importância 0,7 ou mais, ou quem já tem ficha. Projeto, o mesmo. A dona do Lume não ganha ficha: o que for sobre ela vai pra `eu.md` e `preferencias.md`.
4. Pessoa: `indice_pessoa` traz o nome certo, as fontes com quantidades, primeiro e último contato, o resumo, o aprendido, as pendências e os relacionados. É daí que sai a ficha: quem é, a relação, o canal e a frequência numa frase, os links pros projetos e pras pessoas próximas.
5. Projeto: o `projeto` das coisas aprendidas é o slug do arquivo (`projetos/<slug>.md`); use o mesmo. `indice_fatos` com `projeto` traz o que se sabe dele; `indice_buscar` com o nome acha o resto.
6. Itens: das coisas aprendidas, só vira nota o que merece estar à mão em toda conversa: decisões, combinados e prazos em aberto, números que definem um projeto, mudanças de status, eventos que vêm aí. O resto fica no índice, que o Lume consulta quando precisa. Prefira as de importância alta e as vistas mais de uma vez, e escreva a frase do seu jeito, não copiada.
7. Na dúvida (pessoa trocada, data estranha), `indice_linha_do_tempo` com a pessoa e a data mostra os registros de onde a coisa veio. Se estiver errada, conserte no índice com `indice_fatos_editar` (`corrigir` ou `apagar`) e não anote.

## Fonte que o índice ainda não tem
Fonte recém-conectada: o índice sincroniza a cada 5 minutos e aprende aos poucos. Se `indice_status` já mostra registros dela mas quase nada aprendido, leia os registros com `indice_linha_do_tempo` (`fonte`, `desde` da janela, `limite` 100) e tire os itens você mesmo. Se ainda não há registro nenhum, ou o índice não responde, use as ferramentas da própria fonte:
- `whatsapp` e `imessage`: `*_conversas` com limite 60, ordenadas por `total` e `ultima`; pras 15 mais relevantes ou que mudaram na janela, `*_ler` com limite 5, só como prévia.
- `gmail`: `gmail_buscar` com `newer_than:30d -category:promotions -category:social -category:updates -category:forums` e `in:sent newer_than:30d`, limite 50 cada. Newsletter e notificação não contam.
- `agenda`: `agenda_listar` dos últimos 90 e dos próximos 30 dias.
- `granola`, `linear`, `notion`, `otto` e conectores de números: as ferramentas de leitura do servidor com esse id (`list_*`, `get_*`, `search_*`).
- `notas`: `notas_listar` (limite 50, mais recentes) e `notas_ler` nas que parecem de projeto, pessoa ou decisão.
- `pegada` e plataformas: skill `pegada-digital`.

## Regras que valem pra tudo
- Frases curtas, suas. Nunca texto literal de mensagem ou e-mail, nunca segredo (senha, token, chave, cartão), nunca saúde, finanças ou vida íntima de terceiros.
- Procure antes de criar. Ficha: pelo nome, sobrenome, apelido e e-mail (`memoria_buscar` e Grep em `pessoas/` e `projetos/`). Item: por duas ou três palavras do assunto. Achou: edite. O status novo substitui o velho, com a data; `fontes` ganha a fonte nova; `atualizado` fica com a data de hoje. Nunca duas fichas pra mesma pessoa ou projeto, mesmo com grafia diferente entre canais, nem dois itens pro mesmo assunto.
- Frontmatter de toda nota: `tipo`, `importancia`, `atualizado` (hoje) e `fontes: [ids]` com as fontes que contribuíram (`whatsapp`, `gmail`, `granola`, `linear`...). A fonte de uma coisa aprendida vem no campo `fonte` dela.
- Slug em minúsculas, sem acento, com hífen. O do item são as palavras-chave do título (`marcos-topou-preco-anual`).
- Links: o item começa pela âncora e cita os outros envolvidos. A ficha linka os projetos da pessoa, ou as pessoas do projeto. A ficha não lista os itens: o link do item já liga os dois.
- Importância do item: 4 pra decisão, prazo ou combinado em aberto; 3 o normal; 2 contexto. Da ficha: 5 cônjuge, sócio ou projeto principal; 4 contato semanal ou projeto ativo; 3 mensal; 2 esporádico. As quantidades de `indice_pessoa` dizem a frequência.
- Item que já se resolveu (prazo cumprido, evento que passou, tarefa marcada como feita no índice): atualize pro desfecho se ele importa, com a data.
- Grave em paralelo: até 10 notas por resposta, várias chamadas de escrita de uma vez.
- Fonte não ligada, "Não configurado" ou erro: pule em silêncio.
- `eu.md`: acrescente os links das fichas novas nas seções certas. Ao escrever nele, apague a linha `<!-- lume:template -->` se ainda existir; enquanto ela existe, o app considera o arquivo vazio.

## Notas no formato antigo
Ficha com linhas de histórico, status, combinados, pendências ou decisões, e nota de fato que junta assuntos diferentes (como `fatos/base-metricas.md`): quebre. Cada linha que conta um fato vira um item com a ficha certa como âncora, e a ficha fica só com quem é. Mova, não perca nada. Uma nota de fato que ficou vazia depois disso pode virar ficha de projeto ou ficar só com o resumo. `fatos/carreira.md` e `fatos/presenca-digital.md` ficam como estão. Faça isso sempre que tocar numa ficha antiga, e em todas quando a fonte for `todas`.

## Janela
- Primeira construção da fonte (nenhuma nota com ela em `fontes`), sem janela: 90 dias.
- `hoje`: as 24 horas antes de "Agora:". É o que a rotina da noite usa.
- Fonte já construída, sem janela: desde a `atualizado` mais recente das notas que têm essa fonte.

## O que muda por fonte
- `contatos`: não cria nada. Pra cada ficha em `pessoas/`, `indice_pessoa` pelo nome (ou `contatos_buscar`) acerta a grafia e mostra duplicatas: a mesma pessoa com nome diferente em canais diferentes vira uma ficha só. Telefone e e-mail não entram.
- `whatsapp` e `imessage`: grupo não vira pessoa; grupo de trabalho ou de projeto rende itens no projeto.
- `gmail`: quem aparece muito ganha ficha, com a empresa pelo domínio e o cargo pela assinatura.
- `agenda`: reunião recorrente vira item no projeto ou na pessoa ("Semanal do Meu App às terças, 10h"). O que vem nos próximos 30 dias, confira com `agenda_listar` (o índice pode não ter o futuro inteiro). Participante frequente ganha ficha. Compromisso fixo pessoal (treino, escola, terapia) vai pra Rotina em `eu.md`, sem detalhe sensível.
- `granola`: cada decisão vira item em `decisoes/`; ação com prazo vira item de importância 4 e também `- [ ]` no `inbox.md`. O tema é o projeto, os participantes ganham ficha.
- `linear`: o projeto ganha ficha (o que é, chave do time, responsáveis). Status, próximo marco, o que está travado e as entregas da janela viram itens, até 6 por projeto. Issue comum não vira item.
- `otto`: redes, temas e ritmo em `fatos/presenca-digital.md`; post sobre um projeto vira item nele ("Post do lançamento do Meu App agendado pra 28/10").
- `stripe`, `revenuecat`, `superwall`, `supabase`, `metricas` e outros conectores de números: cada número que importa vira item no projeto com a data no título ("Meu App: 120 assinantes ativos em 26/10"). Número novo atualiza o item do mesmo indicador.
- `notas`: ideia, plano ou decisão vira item na ficha certa; lista solta de ideias vira linha em `inbox.md`. Nunca copie a nota inteira.
- `pegada` e plataformas (`linkedin`, `x`, `instagram`, `threads`, `tiktok`, `facebook`): aplique a skill `pegada-digital`. Empresas e projetos da carreira que ainda importam ganham ficha e itens.
- `todas`: primeiro quebre as notas no formato antigo; depois as pessoas e os projetos da janela inteira, de todas as fontes de uma vez, dos mais importantes pros menos.

## Resposta
Uma linha só, nada mais: "Mente: +2 pessoas, +1 projeto, +23 itens, 4 atualizados". Sem mudança: "Mente: nada novo".
