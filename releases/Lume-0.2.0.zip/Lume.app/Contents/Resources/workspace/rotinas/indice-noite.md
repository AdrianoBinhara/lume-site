---
quando: "50 23 * * *"
ativa: true
silenciosa: true
---
/consolidar-indice
Rotina automática da noite, silenciosa, depois do fechamento. Ninguém está digitando: não faça perguntas, não inicie onboarding. Revise o que o Lume aprendeu nas últimas 24 horas seguindo a skill consolidar-indice: junte repetidos, corrija ou apague os errados, atualize as fichas de quem ganhou coisas novas e escreva de 3 a 5 insights novos com evidência, no máximo 300 coisas aprendidas. Se deu tudo certo, responda exatamente NADA; se não conseguiu usar o índice, responda uma linha dizendo isso.
