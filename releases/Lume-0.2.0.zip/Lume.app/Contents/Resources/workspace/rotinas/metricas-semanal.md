---
quando: "0 9 * * 1"
ativa: true
silenciosa: true
---
Rotina automática de segunda-feira, silenciosa. Ninguém está digitando: não faça perguntas, não inicie onboarding. Use a skill metricas e monte a revisão da semana: 7d contra a média de 30d por app, anomalias, e uma linha de leitura geral. Até 12 linhas, pra ler no celular. Se nenhuma fonte de métricas estiver configurada ou não houver dado, responda exatamente NADA.
