---
quando: "0 7 * * *"
ativa: true
silenciosa: false
---
/briefing-da-manha
Rotina automática da manhã. Ninguém está digitando: não faça perguntas, não espere resposta, não inicie onboarding. Monte o briefing de hoje seguindo a skill briefing-da-manha e responda só com o briefing, pronto pra ler no celular.
