---
quando: "30 23 * * *"
ativa: true
silenciosa: true
---
/fechamento-do-dia
Rotina automática da noite, silenciosa. Ninguém está digitando: não faça perguntas, não inicie onboarding. Primeiro rode a skill construir-mente com o argumento "todas hoje" (só o que mudou nas últimas 24 horas nas fontes ligadas), depois consolide o dia na memória seguindo a skill fechamento-do-dia. Se a Mente mudou, responda só a linha "Mente: ..."; se não houver nada a avisar, responda exatamente NADA.
