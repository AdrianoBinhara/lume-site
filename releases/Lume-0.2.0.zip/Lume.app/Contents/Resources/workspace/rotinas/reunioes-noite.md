---
quando: "50 22 * * *"
ativa: true
silenciosa: true
---
/aprender-reunioes
Rotina automática da noite, silenciosa, antes do fechamento. Ninguém está digitando: não faça perguntas, não inicie onboarding. Leia as reuniões do Granola que o índice ainda não leu, até 8 e as mais novas primeiro, seguindo a skill aprender-reunioes: notas e transcrição inteiras, de 20 a 30 coisas aprendidas por reunião de 10 minutos, gravadas com indice_aprender. Se deu tudo certo ou não havia reunião pendente, responda exatamente NADA; se não conseguiu usar o índice ou o Granola, responda uma linha dizendo isso.
