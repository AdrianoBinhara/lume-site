---
tipo: preferencia
importancia: 5
atualizado: 2026-10-26
fontes: []
---
<!-- lume:template -->
# Preferências

Preenchido pelo Lume na primeira conversa. Pode editar à vontade.

## Tom e formato
(direto, bem-humorado, formal; tamanho das respostas; emoji sim ou não)

## Idioma
(em que língua conversar; em que língua escrever e-mails e posts)

## Avisos proativos
(o que quero saber sem pedir: e-mails de quem, mensagens de quem, métricas, prazos)

## Nunca sem perguntar
(o que o Lume nunca deve fazer sem me consultar antes, além do que já pede aprovação)

## Horários
(briefing da manhã, fechamento da noite, período de silêncio)

## Aprovações
(o que posso aprovar de olhos fechados, o que quero ver com calma)
