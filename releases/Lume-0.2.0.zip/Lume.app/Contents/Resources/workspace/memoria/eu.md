---
tipo: fato
importancia: 5
atualizado: 2026-10-26
fontes: []
---
<!-- lume:template -->
# Eu

Preenchido pelo Lume na primeira conversa. Pode editar à vontade.

## Quem sou
(nome, como gosto de ser chamado, cidade, idioma)

## Trabalho
(o que faço, empresa, papel)

## Projetos
(um por linha, linkando o arquivo em projetos/ e dizendo o que é)

## Pessoas importantes
(um por linha, linkando o arquivo em pessoas/ e dizendo a relação)

## Trajetória e redes
(uma linha, linkando carreira e presenca-digital em fatos/ quando existirem)

## Rotina
(horários de trabalho, treino, família, quando não incomodar)

## Integrações que uso
(e-mail, agenda, iMessage, WhatsApp, Notas, Granola, Linear, Otto, métricas, saúde)
