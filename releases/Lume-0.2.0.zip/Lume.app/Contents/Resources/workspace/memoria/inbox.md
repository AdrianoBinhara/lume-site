---
tipo: fato
importancia: 1
atualizado: 2026-10-26
---
# Inbox

Anotações rápidas que ainda não têm lugar. A rotina da noite move cada item pro arquivo certo e limpa aqui.

Pendências ficam como `- [ ] texto (de quem, até quando)` e aparecem no briefing da manhã até virarem `- [x]`.
