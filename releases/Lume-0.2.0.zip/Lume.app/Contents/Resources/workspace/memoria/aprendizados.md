---
tipo: aprendizado
importancia: 3
atualizado: 2026-10-26
---
# Aprendizados

Lições e correções, uma linha por entrada, com data, mais recente embaixo. Formato: `- AAAA-MM-DD: o que aprendi`. O fechamento da noite condensa o que ficou velho e move preferência durável pra `preferencias.md`.
